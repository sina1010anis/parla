<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>پنل مدریت parla</title>
    <link rel="shortcut icon" href="<?php echo e(url('image/logo/'.$logo_footer->src)); ?>">
</head>
<body>
<div id="app">
    <?php echo $__env->make('admin.include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid overflow-scroll" style="height: 100vh">
        <?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('errors.formAuth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('admin'); ?>
    </div>
    <blur-vue></blur-vue>
</div>
</body>
<script src="<?php echo e(url('js/app.js')); ?>"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/30.0.0/classic/ckeditor.js"></script>
<?php echo $__env->yieldContent('script'); ?>
</html>
<?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/admin/index.blade.php ENDPATH**/ ?>