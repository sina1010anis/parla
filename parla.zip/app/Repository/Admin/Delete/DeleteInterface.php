<?php

namespace App\Repository\Admin\Delete;

interface DeleteInterface
{
    public function delete($id);
}
