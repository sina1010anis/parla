@extends('user.index')

@section('index')
    <div class="w-100 bg-white rounded-3 shadow p-2 h-100" style="min-height: 661px">
        <p>پیام</p>
    </div>
@endsection
