<?php $__env->startSection('index'); ?>
    <?php echo $__env->make('front.include.hedare', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('front.include.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('errors.formAuth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <slide-index :sliders="<?php echo e($sliders); ?>" :banner="<?php echo e($banner_top); ?>"></slide-index>

    <banner-center :banners="<?php echo e($banner_center); ?>"></banner-center>

    <best-buy mode="0" :products="<?php echo e($products->where('discount' , '!=' , 0)->get()); ?>"
              title="پیشنهاد ویژه">

    </best-buy>

    <banner-end :banner="<?php echo e($banner_end); ?>"></banner-end>

    <best-buy mode="1" :products="<?php echo e($products_2->take(10)->orderBy('id' , 'DESC')->get()); ?>" title="جدیدترین محصولات">
        <template #other_product>
            <?php if($products_2->count() >= 10): ?>
                <span class="card m-4 position-relative overflow-hidden" style="width: 18rem;">
                    <a href="<?php echo e(route('product.all' , ['mode' => 'new'])); ?>" class=" w-100 h-100 d-flex justify-content-center align-items-center" style="text-decoration: none!important;">
                        <i class="bi bi-plus-circle color-b-600 f-22"></i>
                    </a>
                </span>
            <?php endif; ?>
        </template>
    </best-buy>

    <best-buy mode="1" :products="<?php echo e($products_3->take(10)->orderBy('view' , 'DESC')->get()); ?>" title="بیشترین بازدید">
        <template #other_product>
            <?php if($products_2->count() >= 10): ?>
                <span class="card m-4 position-relative overflow-hidden" style="width: 18rem;">
                    <a href="<?php echo e(route('product.all' , ['mode' => 'view'])); ?>" class=" w-100 h-100 d-flex justify-content-center align-items-center" style="text-decoration: none!important;">
                        <i class="bi bi-plus-circle color-b-600 f-22"></i>
                    </a>
                </span>
            <?php endif; ?>
        </template>
    </best-buy>

    <?php echo $__env->make('front.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/front/section/index.blade.php ENDPATH**/ ?>