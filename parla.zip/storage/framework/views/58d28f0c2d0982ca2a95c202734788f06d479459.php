<?php $__env->startSection('index'); ?>
    <div class="col-12 position-relative">
        <div><h5 class="text-end font-S my-2 color-b-600">محصولات سیو شده</h5></div>
        <div class="line"></div>
    </div>
    <div class="col-12 overflow-scroll bg-light rounded-3 position-relative" style="height: 500px;background-color:unset!important; ">
        <?php if($save_products->count() != 0): ?>
            <?php $__currentLoopData = $save_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $save): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('product.show' , ['slug'=> $save->product->slug])); ?>" class="card d-inline-block m-2 " style="width: 18rem;text-decoration: none!important;">
                    <img src="<?php echo e(url('image/product/'.$save->product->image)); ?>" class="card-img-top" alt="<?php echo e($save->product->name); ?>">
                    <div class="card-body color-b-600 f-14">
                        <p align="center" class="card-text"><?php echo e($save->product->name); ?></p>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <count-vue image="error_2.png" text="محصولی یافت نشد !"></count-vue>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/user/page/save.blade.php ENDPATH**/ ?>