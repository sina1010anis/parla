<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Parla (<?php echo e(auth()->user()->name); ?>)</title>
    <link rel="shortcut icon" href="<?php echo e(url('image/logo/'.$logo_footer->src)); ?>">
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
</head>
<body>
<div id="app" class="container-fluid box-am overflow-hidden">
    <?php echo $__env->make('front.include.hedare', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('front.include.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('errors.formAuth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-12 col-lg-9 my-3 order-2 order-lg-1">
            <div class="row ms-0 w-100 bg-white rounded-3 shadow p-2 h-100" style="min-height: 595px">
                <?php echo $__env->yieldContent('index'); ?>
            </div>
        </div>
        <div class="col-12 col-lg-3  my-3 order-1 order-lg-2">
            <?php echo $__env->make('user.include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <blur-vue></blur-vue>
    <?php echo $__env->make('front.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="<?php echo e(mix('js/app.js')); ?>"></script>
</html>




<?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/user/index.blade.php ENDPATH**/ ?>