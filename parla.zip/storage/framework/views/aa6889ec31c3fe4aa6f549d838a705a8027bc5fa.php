<?php $__env->startSection('admin'); ?>
    <div class=" p-2 ">
        <div class="col-12  bg-white p-4 rounded-3 shadow">
            <h5 class="color-b-700 text-end">پیام های محصولات</h5>
            <div class="line"></div>
            <div class="row">
                <?php $__currentLoopData = $product_all_admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($product->comments->count() != 0): ?>
                        <div class="col-12 col-md-6">
                            <div class="rounded-3  p-2  bg-light">
                                <h5 class="color-b-600 text-end"><?php echo e($product->name); ?> : <?php echo e($product->comments->count()); ?></h5>
                                <div class="line"></div>
                                <?php $__currentLoopData = $product->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="p-2 bg-light rounded-3">
                                        <h6 class="color-b-600 text-end" dir="rtl"><?php echo e($comment->title); ?></h6>
                                        <p class="color-b-500 text-end" dir="rtl"><?php echo e($comment->text); ?></p>
                                        <?php if($comment->src_image_user != NULL): ?>
                                            <div class="obj-center">
                                                <img src="<?php echo e(url('image/comment/'.$comment->src_image_user)); ?>"
                                                     style="width: 150px;" alt="<?php echo e($comment->src_image_user); ?>">
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <button @click="editStatusMessage('<?php echo e($comment->id); ?>' , 'comment')" class="<?php echo e(($comment->status == 0) ? 'btn btn-danger btn-sm ' : ' btn-sm btn btn-success'); ?>">
                                        <?php echo e(($comment->status == 0) ? 'غیر فعال' : 'فعال'); ?>

                                    </button>
                                    <button @click="new_comment_reply('<?php echo e($comment->id); ?>')" class="btn btn-primary btn-sm ">
                                        پاسخ
                                    </button>
                                    <?php $__currentLoopData = $comment->reply_commet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="p-2 my-2" style="background-color: #e6ffe6">
                                            <p class="color-b-500 text-end" dir="rtl"><?php echo e($reply->text); ?></p>
                                            <button @click="editStatusMessage('<?php echo e($reply->id); ?>' , 'reply')" class="<?php echo e(($reply->status == 0) ? 'btn btn-danger btn-sm ' : ' btn-sm btn btn-success'); ?>">
                                                <?php echo e(($reply->status == 0) ? 'غیر فعال' : 'فعال'); ?>

                                            </button>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="line"></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    </div>
    <div class="form-comment-reply bg-white rounded-3 shadow position-fixed bg-info p-3">
        <h5 class="font-S color-b-700 text-center">پاسخ به کامنت</h5>
        <div class="line"></div>
        <div class="form-floating">
                    <textarea v-model="text_comment" class="form-control form-login text-end h-textarea" dir="rtl"
                              placeholder="پیام" id="floatingTextarea"></textarea>
            <label class="d-block text-end float-start" dir="rtl" for="floatingTextarea">پیام</label>
        </div>
        <button @click="new_comment" type="button" class="btn btn-lg btn-red f-13 mt-3">ارسال</button>
        <button @click="cls_page_new_comment_reply" type="button" class="btn btn-lg btn-light f-13 ms-3 mt-3">
            بستن
        </button>
    </div>
    <div class="blur"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/admin/page/messageProduct.blade.php ENDPATH**/ ?>