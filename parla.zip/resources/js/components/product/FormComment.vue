<template>
    <div class="group-form-new-comment abstract-center">

    </div>
</template>

<script>
export default {
    name: "FormComment"
}
</script>

<style scoped>

</style>
