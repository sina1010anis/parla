<div class="w-100 bg-white rounded-3 shadow p-3">
    <div class="text-center">
        <i class="bi bi-person-workspace color-b-700" style="font-size:50px;"></i>
        <p class="f-15 mt-4 mb-0"><b><?php echo e(auth()->user()->name); ?></b></p>
        <p class="f-12 color-b-500"><?php echo e(jdate(auth()->user()->created_at)->format('%B %d، %Y')); ?></p>
        <br>
        <div class="d-flex justify-content-center box-item-panel-user">
            <?php if(auth()->user()->status == 2): ?>
                <span  title="پنل مدیر"><a class="p-0 m-0 obj-center" href="<?php echo e(route('admin.index')); ?>"><i class="bi bi-person-rolodex mx-2 px-2 py-2"></i></a></span>
            <?php else: ?>
                <span title="پشتیبانی"><a class="p-0 m-0 obj-center" href="<?php echo e(route('user.support')); ?>"><i class="bi bi-life-preserver mx-2 px-2 py-2 <?php if($count_support != 0): ?>  shadow-red <?php endif; ?>"></i></a></span>
            <?php endif; ?>
            <span  title="پروفایل"><a class="p-0 m-0 obj-center" href="<?php echo e(route('user.profile')); ?>"><i class="bi bi-person mx-2 px-2 py-2"></i></a></span>
            <span  title="محصولات ذخیره شده"><a class="p-0 m-0 obj-center" href="<?php echo e(route('user.save')); ?>"><i class="bi bi-star mx-2 px-2 py-2"></i></a></span>
            <span  title="ادرس"><a class="p-0 m-0 obj-center" href="<?php echo e(route('user.address')); ?>"><i class="bi bi-geo-alt mx-2 px-2 py-2"></i></a></span>
        </div>
        <div class="line"></div>
    </div>
    <div>
        <ul class="m-0 p-0">
            <li style="list-style: none" class="text-end p-3 pointer item-menu-panel-user rounded-3 position-relative">
                <a href="<?php echo e(route('home')); ?>" class="w-100 h-100">
                     <div class="d-inline-block me-3 f-13 position-relative color-b-700" style="bottom: 2px">خانه</div>
                    <div class="d-inline-block text-end f-20"><i style="color:#c1ab70" class="bi bi-house"></i></div>
                </a>
            </li>
            <li style="list-style: none" class="text-end p-3 pointer item-menu-panel-user rounded-3 position-relative">
                <a href="<?php echo e(route('user.tracking')); ?>" class="w-100 h-100">
                    <div class="d-inline-block me-3 f-13 position-relative color-b-700" style="bottom: 2px">پیگیری سفارشات</div>
                    <div class="d-inline-block text-end f-20"><i style="color:#c1ab70" class="bi bi-arrow-down-up"></i></div>
                </a>
            </li>
            <li style="list-style: none" class="text-end p-3 pointer item-menu-panel-user rounded-3 position-relative">
                <a href="<?php echo e(route('user.cart')); ?>" class="w-100 h-100">
                    <div class="d-inline-block me-3 f-13 position-relative color-b-700" style="bottom: 2px">سبد خرید (خرید نهایی)</div>
                    <div class="d-inline-block text-end f-20"><i style="color:#c1ab70" class="bi bi-bag"></i></div>
                </a>
            </li>
            <li style="list-style: none" class="text-end p-3 pointer item-menu-panel-user rounded-3 position-relative">
                <a href="<?php echo e(route('user.custom')); ?>" class="w-100 h-100">
                    <div class="d-inline-block me-3 f-13 position-relative color-b-700" style="bottom: 2px">سفارش محصول خاص</div>
                    <div class="d-inline-block text-end f-20"><i style="color:#c1ab70" class="bi bi-brush"></i></div>
                </a>
            </li>
            <li style="list-style: none" class="text-end p-3 pointer item-menu-panel-user rounded-3 position-relative">
                <a href="<?php echo e(route('user.calculator')); ?>" class="w-100 h-100">
                    <div class="d-inline-block me-3 f-13 position-relative color-b-700" style="bottom: 2px">محسابه قیمت فریم</div>
                    <div class="d-inline-block text-end f-20"><i style="color:#c1ab70" class="bi bi-calculator"></i></div>
                </a>
            </li>
            <li style="list-style: none" class="text-end p-3 pointer item-menu-panel-user rounded-3 position-relative">
                <a href="<?php echo e(route('logout')); ?>" class="w-100 h-100">
                    <div class="d-inline-block me-3 f-13 position-relative color-b-700" style="bottom: 2px">
                        <form action="<?php echo e(route('logout')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button class="unset" type="submit">خروج</button>
                        </form>
                    </div>
                    <div class="d-inline-block text-end f-20"><i style="color:#ff6060" class="bi bi-x-square"></i></div>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/user/include/menu.blade.php ENDPATH**/ ?>