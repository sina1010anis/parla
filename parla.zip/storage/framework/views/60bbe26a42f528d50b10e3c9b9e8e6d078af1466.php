<header-vue :logo="<?php echo e($logo_footer); ?>"></header-vue>
<?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/front/include/hedare.blade.php ENDPATH**/ ?>