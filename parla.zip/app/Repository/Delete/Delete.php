<?php

namespace App\Repository\Delete;

use App\Models\card;

abstract class Delete
{

}
