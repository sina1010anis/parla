<?php $__env->startSection('index'); ?>
    <div class="col-12 position-relative">
        <div><h5 class="text-end font-S my-2 color-b-600"> سبد خرید</h5></div>
        <div class="line"></div>
    </div>
    <div class="col-12 overflow-scroll rounded-3 position-relative row" style="height: 400px">
        <?php
            $total_price = 0;
        ?>
        <?php if(auth()->user()->address_id != 0): ?>
            <?php if($card_user->count() != 0): ?>
                <?php $__currentLoopData = $card_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $total_price += $card->total_price;
                    ?>
                    <div
                        id="card_user_<?php echo e($card->id); ?>"
                        class="col-md-3 mx-md-2 my-2 p-2 position-relative shadow-sm rounded-3  item-card-view">
                        <img src="/image/product/<?php echo e($card->product->product->image); ?>" class="w-100" alt="">

                        <span class="position-absolute model-color rounded-circle"
                              style="background-image: url('/image/color/<?php echo e($card->color->code); ?>')"></span>
                        <span class="font-Y f-11 pointer" style="color: red"><i
                                @click="delete_product_to_card(<?php echo e($card->id); ?>)"
                                class="bi bi-trash"></i></span>
                        <p class="text-center color-b-600 f-12"><?php echo e($card->product->product->name); ?></p>
                        <p class="text-center color-b-600 f-12">تعداد : <?php echo e($card->number); ?></p>
                        <p class="text-center color-b-600 f-12">مدل : <?php echo e($card->product->name); ?></p>
                        <div class="line"></div>
                        <p class="text-center f-13">قیمت کل : <?php echo e($card->total_price); ?></p>
                        <?php if($card->product->product->discount != 0): ?>
                            <p class="text-center f-13 " style="color: red"><b>تخفیف اعمال شده است</b></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <count-vue image="card.png" text="سبد خرید خالی است !"></count-vue>
            <?php endif; ?>
        <?php else: ?>
            <count-vue image="location.png" text="لطفا ادرس را در پنل خود وارد کنید !"></count-vue>

        <?php endif; ?>
    </div>
    <?php if(auth()->user()->address_id != 0): ?>
        <?php if($card_user->count() != 0): ?>
            <div class="col-12 p-2 obj-center m-3" style="height: 50px">
                <span class="float-end mx-2 f-14 color-b-800 text-total-price-send-factor p-2 bg-light rounded-3">جمع قیمت محصول : <?php echo e($total_price); ?></span>
            </div>
            <div class="col-12 obj-center m-3">
                <?php if((int)$total_price <= (int)$free_send->price): ?>
                    <span class="float-end mx-2 f-14 color-b-800 text-total-price-send-factor p-2 bg-light rounded-3">هزینه ارسال : <?php echo e($my->address->city->price_post); ?></span>
                <?php else: ?>
                    <span class="float-end mx-2 f-14 color-b-800 text-total-price-send-factor p-2 bg-light rounded-3">هزینه ارسال : رایگان</span>
                <?php endif; ?>
            </div>
            <div class="col-12 obj-center m-3">
                <?php if((int)$total_price <= (int)$free_send->price): ?>
                    <span class="float-end mx-2 f-16 color-b-900 text-total-price-send-factor p-2 bg-light rounded-3">قیمت پرداختی : <?php echo e($my->address->city->price_post + $total_price); ?></span>
                <?php else: ?>
                    <span class="float-end mx-2 f-16 color-b-900 text-total-price-send-factor p-2 bg-light rounded-3">قیمت پرداختی : <?php echo e($total_price); ?></span>
                <?php endif; ?>
            </div>
            <div class="col-12 m-2">
                <button @click="new_factor" class="btn btn-red btn-lg align-items-center py-0 px-4 w-100">خرید</button>
            </div>
            <div class="page-new">
                <h6 class="text-center font-S my-2 color-b-600">ارسال به درگاه</h6>
                <div class="line"></div>
                <div class="row">
                    <p class="text-center f-13" style="color: red">برای پرداخت اطمینان دارید ؟</p>
                </div>
                <a href="<?php echo e(route('user.send')); ?>" type="button" class="btn btn-lg btn-red f-13 mt-3">بله</a>
                <button @click="cls_page_new_comment_reply" type="button" class="btn btn-lg btn-light f-13 ms-3 mt-3">
                    خیر
                </button>
            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/user/page/cart.blade.php ENDPATH**/ ?>