<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Parla</title>
    <link rel="shortcut icon" href="<?php echo e(url('image/logo/'.$logo_footer->src)); ?>">
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
    <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>
<div id="app" class="container-fluid box-am overflow-hidden">
    <?php if($banners_up->count() == 1): ?>
        <?php $__currentLoopData = $banners_up; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner_up): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($banner_up->location == 4): ?>
                <div class="banner-up w-100 p-2 position-absolute" style="background-color: <?php echo e($banner_up->src); ?>;left: 0;z-index: 20">
                    <p class="text-center mb-0"><a href="<?php echo e($banner_up->href); ?>" class="f-14  color-b-100"  style="text-decoration: none!important;"><?php echo e($banner_up->name); ?></a></p>
                    <button type="button" class="btn-close position-absolute f-14 color-b-100" @click="hide_banner_up" style="top: 7px" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php echo $__env->yieldContent('index'); ?>
</div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="<?php echo e(mix('js/app.js')); ?>"></script>
</html>
<?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/front/index.blade.php ENDPATH**/ ?>