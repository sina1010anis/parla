<?php $__env->startSection('admin'); ?>
    <div class="row p-2 ">
        <div class="col-md-6  bg-white p-4 rounded-3 shadow">
            <p class="f-16 font-S color-b-700 text-end">صفحه لوگو</p>
            <form action="<?php echo e(route('admin.edit.logo')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="formFile"  class="form-label f-13 color-b-500">اپلود عکس</label>
                    <input name="image" class="form-control" type="file" id="formFile">
                </div>
                <button type="submit" class="btn btn-lg btn-danger f-13 ms-3 mt-3">
                    ارسال
                </button>
            </form>
        </div>
        <div class="col-md-6  mt-3 bg-white p-4 rounded-3 shadow text-center">
            <img style="width: 100px;" src="<?php echo e(url('/image/logo/'.$logo_footer->src)); ?>" alt="لوگو">
        </div>
    </div>
    <?php echo $__env->make('admin.include.about.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/admin/page/logoPage.blade.php ENDPATH**/ ?>