<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Parla</title>
</head>
<body>
<div id="app">
    <payment-vue  code="<?php echo e($code); ?>" status="<?php echo e($status); ?>" text="<?php echo e($tip); ?>"></payment-vue>
</div>
</body>
<script src="<?php echo e(mix('js/app.js')); ?>"></script>
</html>
<?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/user/buy/payment.blade.php ENDPATH**/ ?>