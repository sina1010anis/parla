<?php $__env->startSection('title'); ?>
    404 Error :(
<?php $__env->stopSection(); ?>

<?php $__env->startSection('error'); ?>
    <error-page image="404.png" error="404 Error :(" text="صفحه مورد نظر یافت نشده ! "></error-page>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/errors/404.blade.php ENDPATH**/ ?>