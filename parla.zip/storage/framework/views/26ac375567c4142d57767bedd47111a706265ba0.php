<?php $__env->startSection('admin'); ?>
    <div class="row p-2 ">
        <div class="col-md-6 offset-md-3 bg-white p-4 rounded-3 shadow">
            <p class="f-16 font-S color-b-700 text-end">بنر بالا</p>
            <?php if($banners_up->count() == 1): ?>
                <?php $__currentLoopData = $banners_up; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner_up): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e(route('admin.edit.bannerUp' , ['model' => 'all' , 'target' => 'up'])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="formFile" class="form-label f-13 color-b-500 d-block text-end">متن بنر</label>
                            <input name="name" value="<?php echo e($banner_up->name); ?>" dir="rtl" class="form-control text-end" type="text" id="formFile">
                        </div>
                        <div class="mb-3">
                            <label for="formFile"  class="form-label f-13 color-b-500 d-block text-end">ادرس</label>
                            <input name="href" value="<?php echo e($banner_up->href); ?>" class="form-control" type="text" id="formFile">
                        </div>
                        <div class="mb-3">
                            <label for="formFile"  class="form-label f-13 color-b-500 d-block text-end">رنگ بنر</label>
                            <input name="src" value="<?php echo e($banner_up->src); ?>" class="form-control form-control-lg" type="color" id="formFile">
                        </div>
                        <button type="submit" class="btn btn-lg btn-danger f-13 ms-3 mt-3">
                            ارسال
                        </button>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>
        <div class="col-md-6 offset-md-3 bg-white p-4 rounded-3 shadow my-2">
            <p class="f-16 font-S color-b-700 text-end">وضعیت</p>
            <?php if($banners_up->count() == 1): ?>
                <?php $__currentLoopData = $banners_up; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner_up): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e(route('admin.edit.bannerUp' , ['model' => 'status' , 'target' => 'up'])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-lg <?php echo e(($banner_up->location == 4) ? 'btn-success' : 'btn-danger'); ?> f-13 ms-3 mt-3">
                            <?php echo e(($banner_up->location == 4) ? 'فعال' : 'غیر فعال'); ?>

                        </button>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>









    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/admin/page/bannerUp.blade.php ENDPATH**/ ?>