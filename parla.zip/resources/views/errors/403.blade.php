@extends('errors.minimal')

@section('title')
    403 Error :(
@endsection

@section('error')
    <error-page image="404.png" error="403 Error :(" text="صفحه مورد نظر یافت نشده ! "></error-page>
@endsection
