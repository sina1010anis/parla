<template>
    <div class="blur"></div>
</template>

<script>
export default {
    name: "BlurVue"
}
</script>

<style scoped>

</style>
