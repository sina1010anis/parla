<?php $__env->startSection('admin'); ?>
    <div class="row p-2 ">
        <div class="col-md-6 offset-md-3 bg-white p-4 rounded-3 shadow row">
            <p class="f-16 font-S color-b-700 text-end">کابران فعال</p>
                    <div class="line"></div>
                    <div class="bd-example">
                        <table class="table table-striped" dir="rtl">
                            <thead>
                            <tr>
                                <th>ایدی</th>
                                <th>نام</th>
                                <th>ایمیل</th>
                                <th>موبایل</th>
                                <th>تایید موبایل</th>
                                <th>ادرس</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users_admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="f-12 color-b-600"><?php echo e($user->id); ?></td>
                                    <td class="f-12 color-b-600"><?php echo e($user->name); ?></td>
                                    <td class="f-12 color-b-600"><?php echo e($user->email); ?></td>
                                    <td class="f-12 color-b-600"><?php echo e($user->mobile); ?></td>
                                    <td class="f-12 color-b-600"><?php echo ($user->verify_mobile == 0) ? '<span style="color:red">تایید نشده</span>' : '<span style="color:green">تایید شده</span>'; ?></td>
                                    <td class="f-12 color-b-600"><?php echo e(($user->address_id == 0) ? 'ادرسی وارد نشده' : $user->address->city->name . ' - ' . $user->address->state->name . ' - ' . $user->address->address); ?></td>
                                    <td class="f-12 color-b-600"><button @click="view_page_edit_password_user('<?php echo e($user->id); ?>')" class="btn-sm btn btn-primary"><i class="bi bi-key"></i></button></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>

        </div>
    </div>
    <div class="page-new page-password-product overflow-hidden">
        <h6 class="text-center font-S my-2 color-b-600">تغییر رمز عبور</h6>
        <div class="line"></div>
        <div class="row overflow-scroll" style="max-height: 300px">
            <input type="text" class="form-control f-13 my-2" v-model="data_support_panel_admin" placeholder="رمط عبور جدید...">
        </div>
        <button @click="edit_password" type="button" class="btn btn-lg btn-primary f-13 ms-3 mt-3">
            تایید
        </button>
        <button @click="cls_page_new_comment_reply" type="button" class="btn btn-lg btn-light f-13 ms-3 mt-3">
            بستن
        </button>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/admin/page/users.blade.php ENDPATH**/ ?>