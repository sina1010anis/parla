<div class="row obj-center h-100">
    <div class="col-11 col-lg-9 p-2 p-md-5 bg-white rounded-3 shadow row">
        <div class="col-12 col-lg-6 d-none d-lg-block">
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php $__currentLoopData = $slider_login; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="<?php echo e(($loop->index == 0) ? 'active' : ''); ?> carousel-item" data-bs-interval="2000">
                                <img src="/image/slider/sliderLoginRegister/<?php echo e($slider->src); ?>" alt="<?php echo e($slider->name); ?>"
                                     title="<?php echo e($slider->name); ?>" style="width: 400px">
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-6">
            <h5 class="text-end font-S color-b-600">ورود</h5>
            <div class="line" style="background-color: #fdf3d2"></div>
            <br>
            <form action="<?php echo e(route('login')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="input_mobile" class="form-label d-block text-end f-11 color-b-500">شماره موبایل</label>
                    <input name="mobile" type="text"
                           class="form-control form-login <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('mobile')); ?>" dir="rtl" align="right"
                           id="input_mobile" placeholder="شماره موبایل...">
                </div>
                <div class="mb-3">
                    <label for="input_password" class="form-label d-block text-end f-11 color-b-500">رمز عبور</label>
                    <input name="password" type="password"
                           class="form-control form-login color-b-600 f-14 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           dir="rtl" align="right"
                           id="input_password" placeholder="پسورد...">
                </div>
                <br>
                
                
                
                <div class="mb-3">
                    <div class="g-recaptcha"
                         data-sitekey="<?php echo env('RECAPTCHA_SITE_KEY' , '6Lf2euYbAAAAAGIymqU4o_v83Ob8X3kFuMVNtEyN'); ?>"></div>
                </div>
                <div class="col-12">
                    <button class="btn bg-gh color-b-600 px-5" type="submit">ورود</button>
                </div>
            </form>
            <p class="text-end color-b-600 f-12">برای ثبت نام <a href="<?php echo e(route('register')); ?>">کلیک کنید</a></p>
            
            
            
            
            
            
            
        </div>
    </div>
</div>
<?php echo $__env->make('errors.formAuth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/user/form/inc/formLogin.blade.php ENDPATH**/ ?>