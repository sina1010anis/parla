@extends('front.index')

@section('index')
    @include('user.form.inc.formLogin')
@endsection
