<h2{{$slug->name}}</h2>
