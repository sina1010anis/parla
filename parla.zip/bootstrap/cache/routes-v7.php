<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/biscolab-recaptcha/validate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qAJfV1KCQ5XpkcxM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DRDbH79j1CAxSBNO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::b676tCanA1H4O9En',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tt' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3WQszSMDzUvx5yFv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/verify' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verify.mobile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/verify/check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verify.mobile.check',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search/menu/header' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8ivA5dQ3jqsKs2f1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/about' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => '.about',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/product/send/size' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'product.send.size',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/product/new/comment' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'product.new.comment.reply',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/product/save/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'product.save.delete.product',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/product/save/card' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'product.save.card',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/product/delete/card' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'product.delete.card',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/tracking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.tracking',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/cart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.cart',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/address' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.address',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/custom' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.custom',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/calculator' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.calculator',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/support' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.support',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.profile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.save',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/message' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.message',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/new/comment/support' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.new.support',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/new/address' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.new.address',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/new/factor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.new.factor',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/new/custom' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.new.custom',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/new/support/file' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.new.support.file',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/edit/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.edit.profile',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/edit/address' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.edit.address',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/delete/address' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.delete.address',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/send/buy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.send',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/verify/buy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.verify',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/view/factor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.view.factor',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.user',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.users',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/color' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.color',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/factor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.factor',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.factor.page',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/support' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.support',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/about' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.about',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/logo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.logo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.menu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/sub_menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.subMenu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/banner/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.bannerUp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/banner/slider' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.bannerSlider',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/banner/center' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.bannerCenter',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/banner/end' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.bannerEnd',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/slider/end' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.slider',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/slider/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.slider.menu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/slider/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.slider.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.product',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/size/product/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.product.size',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/product/image' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.product.image',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/product/color' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.product.color',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/productT' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.productT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/item' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.item',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/box/footer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.box.footer',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/link/footer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.link.footer',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/item/footer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.item.footer',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/message/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.message.product',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/message/support' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.message.support',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/state' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.state',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/city' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.city',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/free/send' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.free.send',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/view/attr/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.view.attr.product',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.user',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.menu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/slider' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.slider',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/slider/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.slider.menu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/slider/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.slider.login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/sub/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.sub.menu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/image/banner/center' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.image.banner.center',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.product',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/size' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.size',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/image' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.image',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/product/color' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.color.product',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/color' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.color',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/item' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.item',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/box/footer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.box.footer',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/link/footer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.link.footer',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/item/footer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.item.footer',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/state' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.state',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/city' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.city',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/cart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.cart',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/delete/attr' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.delete.attr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/edit/status/order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.status.order',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/edit/status/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.status.product',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/edit/about' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.about',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/edit/status/productT' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.status.productT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/edit/logo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.logo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/edit/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.menu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/edit/menu/name' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.menu.name',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/edit/status/comment' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.status.comment',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/edit/sub/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.sub.menu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/edit/free/send' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.free.send',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/edit/sub/menu/name' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.sub.menu.name',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/edit/pass/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.password.user',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/edit/state' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.state',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/support' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.support',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.product',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.menu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/image/about' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.image.about',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/sub/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.sub.menu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/banner' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.banner',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/slider' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.slider',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/slider/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.slider.menu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/slider/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.slider.login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/size' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.size',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/product/image' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.image.product',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/product/color' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.product.color',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/color' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.color',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/item' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.item',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/box/footer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.box.footer',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/link/footer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.link.footer',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/item/footer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.item.footer',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/comment/support' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.comment.support',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/state' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.state',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/city' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.city',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/attr' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.attr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/video/about' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.video.about',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/new/support/file' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.support.file',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/update/support' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'adminupdate.support',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IiAOQviYci1EHw3U',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gIWLTvSv8pv1dEL3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/reset' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/confirm' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Q1Jugh5xNeN6mtfu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/category/([^/]++)(*:25)|/a(?|ll/([^/]++)(*:48)|dmin/(?|edit/(?|product/(?|([^/]++)(*:90)|all/([^/]++)(*:109))|bannerUp/([^/]++)/([^/]++)(*:144))|new/image/product/([^/]++)(*:179)))|/p(?|roduct/(?|([^/]++)(*:212)|s(?|earch(*:229)|ave(*:240))|comment/([^/]++)(*:265))|assword/reset/([^/]++)(*:296)))/?$}sDu',
    ),
    3 => 
    array (
      25 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'category.show',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      48 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'product.all',
          ),
          1 => 
          array (
            0 => 'mode',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      90 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.product',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      109 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.product.all',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      144 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.bannerUp',
          ),
          1 => 
          array (
            0 => 'model',
            1 => 'target',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      179 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.new.image.productA',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      212 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'product.show',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      229 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'product.search.product',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      240 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'product.save.product',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      265 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'product.new.comment',
          ),
          1 => 
          array (
            0 => 'idProduct',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      296 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::qAJfV1KCQ5XpkcxM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'biscolab-recaptcha/validate',
      'action' => 
      array (
        'uses' => 'Biscolab\\ReCaptcha\\Controllers\\ReCaptchaController@validateV3',
        'controller' => 'Biscolab\\ReCaptcha\\Controllers\\ReCaptchaController@validateV3',
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::qAJfV1KCQ5XpkcxM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DRDbH79j1CAxSBNO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::DRDbH79j1CAxSBNO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::b676tCanA1H4O9En' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000078188e2900000000782888d7";}";s:4:"hash";s:44:"xzAddzK1NBc0HIrbz+CjcsjKL3zVN3xIiqAFRFp/Sr4=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::b676tCanA1H4O9En',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3WQszSMDzUvx5yFv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tt',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Index\\IndexController@test',
        'controller' => 'App\\Http\\Controllers\\Index\\IndexController@test',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3WQszSMDzUvx5yFv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verify.mobile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'verify',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Product\\ProductController@verifyMobile',
        'controller' => 'App\\Http\\Controllers\\Product\\ProductController@verifyMobile',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verify.mobile',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verify.mobile.check' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'verify/check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Product\\ProductController@verifyMobileCheck',
        'controller' => 'App\\Http\\Controllers\\Product\\ProductController@verifyMobileCheck',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verify.mobile.check',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Index\\IndexController@index',
        'controller' => 'App\\Http\\Controllers\\Index\\IndexController@index',
        'namespace' => NULL,
        'prefix' => '/',
        'where' => 
        array (
        ),
        'as' => 'index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8ivA5dQ3jqsKs2f1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'search/menu/header',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Index\\IndexController@searchHeaderMenu',
        'controller' => 'App\\Http\\Controllers\\Index\\IndexController@searchHeaderMenu',
        'namespace' => NULL,
        'prefix' => '/',
        'where' => 
        array (
        ),
        'as' => 'generated::8ivA5dQ3jqsKs2f1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    '.about' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'about',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Index\\IndexController@aboutWe',
        'controller' => 'App\\Http\\Controllers\\Index\\IndexController@aboutWe',
        'namespace' => NULL,
        'prefix' => '/',
        'where' => 
        array (
        ),
        'as' => '.about',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'category.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'category/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Product\\Category\\CategoryController@index',
        'controller' => 'App\\Http\\Controllers\\Product\\Category\\CategoryController@index',
        'namespace' => NULL,
        'prefix' => '/',
        'where' => 
        array (
        ),
        'as' => 'category.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'product.all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'all/{mode}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Product\\ProductController@allView',
        'controller' => 'App\\Http\\Controllers\\Product\\ProductController@allView',
        'namespace' => NULL,
        'prefix' => '/',
        'where' => 
        array (
        ),
        'as' => 'product.all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'product.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'product/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Product\\ProductController@show',
        'controller' => 'App\\Http\\Controllers\\Product\\ProductController@show',
        'as' => 'product.show',
        'namespace' => NULL,
        'prefix' => '/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'product.send.size' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'product/send/size',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Product\\ProductController@sendSize',
        'controller' => 'App\\Http\\Controllers\\Product\\ProductController@sendSize',
        'as' => 'product.send.size',
        'namespace' => NULL,
        'prefix' => '/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'product.search.product' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'product/search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Product\\ProductController@searchProduct',
        'controller' => 'App\\Http\\Controllers\\Product\\ProductController@searchProduct',
        'as' => 'product.search.product',
        'namespace' => NULL,
        'prefix' => '/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'product.new.comment' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'product/comment/{idProduct}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Product\\Comment\\CommentController@newComment',
        'controller' => 'App\\Http\\Controllers\\Product\\Comment\\CommentController@newComment',
        'as' => 'product.new.comment',
        'namespace' => NULL,
        'prefix' => '/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'product.new.comment.reply' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'product/new/comment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Product\\Comment\\CommentController@newCommentReply',
        'controller' => 'App\\Http\\Controllers\\Product\\Comment\\CommentController@newCommentReply',
        'as' => 'product.new.comment.reply',
        'namespace' => NULL,
        'prefix' => '/product',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'product.save.product' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'product/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Product\\ProductController@saveProduct',
        'controller' => 'App\\Http\\Controllers\\Product\\ProductController@saveProduct',
        'as' => 'product.save.product',
        'namespace' => NULL,
        'prefix' => 'product/save',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'product.save.delete.product' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'product/save/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Product\\ProductController@saveDeleteProduct',
        'controller' => 'App\\Http\\Controllers\\Product\\ProductController@saveDeleteProduct',
        'as' => 'product.save.delete.product',
        'namespace' => NULL,
        'prefix' => 'product/save',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'product.save.card' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'product/save/card',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Product\\Card\\CardController@saveCard',
        'controller' => 'App\\Http\\Controllers\\Product\\Card\\CardController@saveCard',
        'as' => 'product.save.card',
        'namespace' => NULL,
        'prefix' => 'product/save',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'product.delete.card' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'product/delete/card',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Product\\Card\\CardController@deleteCard',
        'controller' => 'App\\Http\\Controllers\\Product\\Card\\CardController@deleteCard',
        'as' => 'product.delete.card',
        'namespace' => NULL,
        'prefix' => 'product/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.tracking' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/tracking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@tracking',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@tracking',
        'as' => 'user.tracking',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.cart' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/cart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@cart',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@cart',
        'as' => 'user.cart',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.address' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/address',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@address',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@address',
        'as' => 'user.address',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.custom' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/custom',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@custom',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@custom',
        'as' => 'user.custom',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.calculator' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/calculator',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@calculator',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@calculator',
        'as' => 'user.calculator',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.support' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/support',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@support',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@support',
        'as' => 'user.support',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@profile',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@profile',
        'as' => 'user.profile',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.save' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@save',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@save',
        'as' => 'user.save',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.message' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/message',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@message',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@message',
        'as' => 'user.message',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.new.support' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/new/comment/support',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserNewController@index',
        'controller' => 'App\\Http\\Controllers\\User\\UserNewController@index',
        'as' => 'user.new.support',
        'namespace' => NULL,
        'prefix' => 'user/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.new.address' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/new/address',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@newAddress',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@newAddress',
        'as' => 'user.new.address',
        'namespace' => NULL,
        'prefix' => 'user/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.new.factor' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/new/factor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\Pay\\PayController@newFactor',
        'controller' => 'App\\Http\\Controllers\\Pay\\PayController@newFactor',
        'as' => 'user.new.factor',
        'namespace' => NULL,
        'prefix' => 'user/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.new.custom' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/new/custom',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@newCustom',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@newCustom',
        'as' => 'user.new.custom',
        'namespace' => NULL,
        'prefix' => 'user/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.new.support.file' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/new/support/file',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@newSupportFile',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@newSupportFile',
        'as' => 'user.new.support.file',
        'namespace' => NULL,
        'prefix' => 'user/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.edit.profile' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/edit/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@editProfile',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@editProfile',
        'as' => 'user.edit.profile',
        'namespace' => NULL,
        'prefix' => 'user/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.edit.address' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/edit/address',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@editAddress',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@editAddress',
        'as' => 'user.edit.address',
        'namespace' => NULL,
        'prefix' => 'user/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.delete.address' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/delete/address',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@deleteAddress',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@deleteAddress',
        'as' => 'user.delete.address',
        'namespace' => NULL,
        'prefix' => 'user/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.send' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/send/buy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\Pay\\PayController@send',
        'controller' => 'App\\Http\\Controllers\\Pay\\PayController@send',
        'as' => 'user.send',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.verify' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/verify/buy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\Pay\\PayController@verify',
        'controller' => 'App\\Http\\Controllers\\Pay\\PayController@verify',
        'as' => 'user.verify',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.view.factor' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/view/factor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\User\\UserController@viewFactor',
        'controller' => 'App\\Http\\Controllers\\User\\UserController@viewFactor',
        'as' => 'user.view.factor',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminController@index',
        'as' => 'admin.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.user' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/view/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewUser',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewUser',
        'as' => 'admin.view.user',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.color' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/color',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewColor',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewColor',
        'as' => 'admin.view.color',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.factor' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/view/factor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@factorUser',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@factorUser',
        'as' => 'admin.view.factor',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.support' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/view/support',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewSupport',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewSupport',
        'as' => 'admin.view.support',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.about' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/about',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewAbout',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewAbout',
        'as' => 'admin.view.about',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.logo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/logo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewLogo',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewLogo',
        'as' => 'admin.view.logo',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.menu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewMenu',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewMenu',
        'as' => 'admin.view.menu',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.subMenu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/sub_menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewSubMenu',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewSubMenu',
        'as' => 'admin.view.subMenu',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.bannerUp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/banner/up',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewBannerUp',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewBannerUp',
        'as' => 'admin.view.bannerUp',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.bannerSlider' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/banner/slider',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewBannerSlider',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewBannerSlider',
        'as' => 'admin.view.bannerSlider',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.bannerCenter' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/banner/center',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewBannerCenter',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewBannerCenter',
        'as' => 'admin.view.bannerCenter',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.bannerEnd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/banner/end',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewBannerEnd',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewBannerEnd',
        'as' => 'admin.view.bannerEnd',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.slider' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/slider/end',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewSlider',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewSlider',
        'as' => 'admin.view.slider',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.slider.menu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/slider/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewSliderMenu',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewSliderMenu',
        'as' => 'admin.view.slider.menu',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.slider.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/slider/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewSliderLogin',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewSliderLogin',
        'as' => 'admin.view.slider.login',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.product' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewProduct',
        'as' => 'admin.view.product',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.product.size' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/view/size/product/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewSizeProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewSizeProduct',
        'as' => 'admin.view.product.size',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.product.image' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/view/product/image',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewProductImage',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewProductImage',
        'as' => 'admin.view.product.image',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.product.color' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/view/product/color',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewProductColor',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewProductColor',
        'as' => 'admin.view.product.color',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.productT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/productT',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewProductT',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewProductT',
        'as' => 'admin.view.productT',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.item' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/item',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewItem',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewItem',
        'as' => 'admin.view.item',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.box.footer' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/box/footer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewBoxFooter',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewBoxFooter',
        'as' => 'admin.view.box.footer',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.link.footer' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/link/footer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewLinkFooter',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewLinkFooter',
        'as' => 'admin.view.link.footer',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.item.footer' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/item/footer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewItemFooter',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewItemFooter',
        'as' => 'admin.view.item.footer',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.users' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewUsers',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewUsers',
        'as' => 'admin.view.users',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.message.product' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/message/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewMessageProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewMessageProduct',
        'as' => 'admin.view.message.product',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.message.support' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/message/support',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewMessageSupport',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewMessageSupport',
        'as' => 'admin.view.message.support',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.state' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/state',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewState',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewState',
        'as' => 'admin.view.state',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.city' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/city',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewCity',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewCity',
        'as' => 'admin.view.city',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.free.send' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/free/send',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewFreeSend',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewFreeSend',
        'as' => 'admin.view.free.send',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.factor.page' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/view/factor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewFactor',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewFactor',
        'as' => 'admin.view.factor.page',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.view.attr.product' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/view/attr/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewAttrProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminViewController@viewAttrProduct',
        'as' => 'admin.view.attr.product',
        'namespace' => NULL,
        'prefix' => 'admin/view',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.user' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteUser',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteUser',
        'as' => 'admin.delete.user',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.menu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteMenu',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteMenu',
        'as' => 'admin.delete.menu',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.slider' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/slider',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteSlider',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteSlider',
        'as' => 'admin.delete.slider',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.slider.menu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/slider/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteSliderMenu',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteSliderMenu',
        'as' => 'admin.delete.slider.menu',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.slider.login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/slider/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteSliderLogin',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteSliderLogin',
        'as' => 'admin.delete.slider.login',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.sub.menu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/sub/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteSubMenu',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteSubMenu',
        'as' => 'admin.delete.sub.menu',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.image.banner.center' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/image/banner/center',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteImageBannerCenter',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteImageBannerCenter',
        'as' => 'admin.delete.image.banner.center',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.product' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteProduct',
        'as' => 'admin.delete.product',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.size' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/size',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteSize',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteSize',
        'as' => 'admin.delete.size',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.image' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/image',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteImage',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteImage',
        'as' => 'admin.delete.image',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.color.product' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/product/color',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteColorProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteColorProduct',
        'as' => 'admin.delete.color.product',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.color' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/color',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteColor',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteColor',
        'as' => 'admin.delete.color',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.item' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/item',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteItem',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteItem',
        'as' => 'admin.delete.item',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.box.footer' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/box/footer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteBoxFooter',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteBoxFooter',
        'as' => 'admin.delete.box.footer',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.link.footer' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/link/footer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteLinkFooter',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteLinkFooter',
        'as' => 'admin.delete.link.footer',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.item.footer' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/item/footer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteItemFooter',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteItemFooter',
        'as' => 'admin.delete.item.footer',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.state' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/state',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteState',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteState',
        'as' => 'admin.delete.state',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.city' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/city',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteCity',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteCity',
        'as' => 'admin.delete.city',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.cart' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/cart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteCart',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteCart',
        'as' => 'admin.delete.cart',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.delete.attr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/delete/attr',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteAttr',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminDeleteController@deleteAttr',
        'as' => 'admin.delete.attr',
        'namespace' => NULL,
        'prefix' => 'admin/delete',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.status.order' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/status/order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editStatusOrder',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editStatusOrder',
        'as' => 'admin.edit.status.order',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.product' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/product/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editProduct',
        'as' => 'admin.edit.product',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.status.product' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/status/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editStatusProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editStatusProduct',
        'as' => 'admin.edit.status.product',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.product.all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/edit/product/all/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editProductAll',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editProductAll',
        'as' => 'admin.edit.product.all',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.about' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/about',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editAbout',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editAbout',
        'as' => 'admin.edit.about',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.status.productT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/status/productT',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editStatusProductT',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editStatusProductT',
        'as' => 'admin.edit.status.productT',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.logo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/logo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editLogo',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editLogo',
        'as' => 'admin.edit.logo',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.menu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editMenu',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editMenu',
        'as' => 'admin.edit.menu',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.menu.name' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/menu/name',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editMenuName',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editMenuName',
        'as' => 'admin.edit.menu.name',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.status.comment' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/status/comment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editStatusComment',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editStatusComment',
        'as' => 'admin.edit.status.comment',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.sub.menu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/sub/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editSubMenu',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editSubMenu',
        'as' => 'admin.edit.sub.menu',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.free.send' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/free/send',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editFreeSend',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editFreeSend',
        'as' => 'admin.edit.free.send',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.sub.menu.name' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/sub/menu/name',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editSubMenuName',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editSubMenuName',
        'as' => 'admin.edit.sub.menu.name',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.password.user' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/pass/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editPasswordUser',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editPasswordUser',
        'as' => 'admin.edit.password.user',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.state' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/state',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editState',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editState',
        'as' => 'admin.edit.state',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.bannerUp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit/bannerUp/{model}/{target}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editBannerUp',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminView\\AdminEditController@editBannerUp',
        'as' => 'admin.edit.bannerUp',
        'namespace' => NULL,
        'prefix' => 'admin/edit',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.support' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/support',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newSupport',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newSupport',
        'as' => 'admin.new.support',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.product' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newProduct',
        'as' => 'admin.new.product',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.menu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newMenu',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newMenu',
        'as' => 'admin.new.menu',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.image.about' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/image/about',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newImageAbout',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newImageAbout',
        'as' => 'admin.new.image.about',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.sub.menu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/sub/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newSubMenu',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newSubMenu',
        'as' => 'admin.new.sub.menu',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.banner' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/banner',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newBanner',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newBanner',
        'as' => 'admin.new.banner',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.slider' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/slider',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newSlider',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newSlider',
        'as' => 'admin.new.slider',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.slider.menu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/slider/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newSliderMenu',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newSliderMenu',
        'as' => 'admin.new.slider.menu',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.slider.login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/slider/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newSliderLogin',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newSliderLogin',
        'as' => 'admin.new.slider.login',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.size' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/size',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newSize',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newSize',
        'as' => 'admin.new.size',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.image.product' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/product/image',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newImage',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newImage',
        'as' => 'admin.new.image.product',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.product.color' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/product/color',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newProductColor',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newProductColor',
        'as' => 'admin.new.product.color',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.color' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/color',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newColor',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newColor',
        'as' => 'admin.new.color',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.item' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/item',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newItem',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newItem',
        'as' => 'admin.new.item',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.box.footer' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/box/footer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newBoxFooter',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newBoxFooter',
        'as' => 'admin.new.box.footer',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.link.footer' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/link/footer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newLinkFooter',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newLinkFooter',
        'as' => 'admin.new.link.footer',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.item.footer' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/item/footer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newItemFooter',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newItemFooter',
        'as' => 'admin.new.item.footer',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.comment.support' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/comment/support',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newCommentSupport',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newCommentSupport',
        'as' => 'admin.new.comment.support',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.state' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/state',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newState',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newState',
        'as' => 'admin.new.state',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.city' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/city',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newCity',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newCity',
        'as' => 'admin.new.city',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.attr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/attr',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newAttr',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newAttr',
        'as' => 'admin.new.attr',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.video.about' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/video/about',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newVideoAbout',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newVideoAbout',
        'as' => 'admin.new.video.about',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.support.file' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/support/file',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newSupportFile',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newSupportFile',
        'as' => 'admin.new.support.file',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.new.image.productA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/new/image/product/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newImageProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminNewController@newImageProduct',
        'as' => 'admin.new.image.productA',
        'namespace' => NULL,
        'prefix' => 'admin/new',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'adminupdate.support' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/update/support',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'check',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminUpdateController@updateSupport',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminUpdateController@updateSupport',
        'as' => 'adminupdate.support',
        'namespace' => NULL,
        'prefix' => 'admin/update',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IiAOQviYci1EHw3U' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::IiAOQviYci1EHw3U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gIWLTvSv8pv1dEL3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::gIWLTvSv8pv1dEL3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.confirm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.confirm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Q1Jugh5xNeN6mtfu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Q1Jugh5xNeN6mtfu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verify_mobile',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\HomeController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
