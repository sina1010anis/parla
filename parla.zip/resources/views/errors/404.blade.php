@extends('errors.minimal')

@section('title')
    404 Error :(
@endsection

@section('error')
    <error-page image="404.png" error="404 Error :(" text="صفحه مورد نظر یافت نشده ! "></error-page>
@endsection
