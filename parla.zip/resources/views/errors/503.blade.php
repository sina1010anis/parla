@extends('errors.minimal')

@section('title')
    503 Error :(
@endsection

@section('error')
    <error-page image="503_3.png" error="503 Update :)" text="سایت در حال بروزرسانی است لطفا صبر کنید ! "></error-page>
@endsection
