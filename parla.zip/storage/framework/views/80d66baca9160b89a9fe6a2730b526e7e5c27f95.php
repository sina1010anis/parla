<item-vue :items="<?php echo e($items); ?>"></item-vue>
<footer-vue :link="<?php echo e($link_footer); ?>" :logo="<?php echo e($logo_footer); ?>">
    <template #nmade>
        <?php $__currentLoopData = $nmad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $i->src; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </template>
    <template #footer>
            <?php $__currentLoopData = $title_footers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col mt-3 mb-3">
                    <h5 class="font-Y"><?php echo e($title->name); ?></h5>
                    <ul class="nav flex-column">
                        <?php $__currentLoopData = $title->item_footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item mb-2">
                                <a <?php if($item->like != null): ?> href="<?php echo e($item->link); ?>"
                                   <?php endif; ?> class="nav-link p-0 text-muted font-Y f-13"><?php echo e($item->name); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </template>
    <template #link>
        <?php $__currentLoopData = $link_footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="ms-3">
                <a href="<?php echo e($link->link); ?>" title="<?php echo e($link->name); ?>" class="link-dark f-18 pointer">
                    <i class="<?php echo e($link->icon); ?>"></i>
                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </template>
</footer-vue>
<?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/front/include/footer.blade.php ENDPATH**/ ?>