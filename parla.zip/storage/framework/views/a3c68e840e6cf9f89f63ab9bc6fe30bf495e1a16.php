<?php $__env->startSection('index'); ?>
    <div class="col-12 col-md-3 h-p-595 d-flex flex-column">
        <div class="w-100 p-2 h-148">
            <div class="bg-gh-d-g shadow-sm rounded-3 obj-center flex-column h-100">
                <p class="f-13 color-b-100">در حال پردازش</p>
                <p class="f-20 color-b-100">
                    <b><?php echo e($factor_1); ?></b>
                </p>
            </div>
        </div>
        <div class="w-100 p-2 h-148">
            <div class="bg-gh-d-g shadow-sm rounded-3 obj-center flex-column h-100">
                <p class="f-13 color-b-100">در حال اماده سازی</p>
                <p class="f-20 color-b-100 font-Y">
                    <b><?php echo e($factor_2); ?></b>
                </p>
            </div>
        </div>
        <div class="w-100 p-2 h-148">
            <div class="bg-gh-d-g shadow-sm rounded-3 obj-center flex-column h-100">
                <p class="f-13 color-b-100">در حال ارسال</p>
                <p class="f-20 color-b-100">
                    <b><?php echo e($factor_3); ?></b>
                </p>
            </div>
        </div>

        <div class="w-100 p-2 h-148">
            <div class="bg-gh-d-g shadow-sm rounded-3 obj-center flex-column h-100">
                <p class="f-13 color-b-100">تحویل شده</p>
                <p class="f-20 color-b-100">
                    <b><?php echo e($factor_4); ?></b>
                </p>
            </div>
        </div>

    </div>
    <div class="col-12 col-md-9 row ms-0" style="height: 595px">
        <div class="col-12 p-2 p-md-4 h-50">
            <div class="bg-light h-100 rounded-3 p-2 overflow-hidden">
                <p class="f-13 color-b-700 font-S text-end">سبد خرید</p>
                <div class="line"></div>
                <div class="box-item-panel h-75 overflow-scroll">
                    <?php if($card_user->count() != 0): ?>
                        <?php $__currentLoopData = $card_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div
                                id="card_user_<?php echo e($card->id); ?>"
                                class="w-100 my-2 p-2 position-relative shadow-sm rounded-3 d-flex justify-content-between align-items-center item-card-view"
                                style="height: 100px">
                                <img src="/image/product/<?php echo e($card->product->product->image); ?>" alt="" class="h-100">
                                <span class="font-Y color-b-700 f-11">قیمت کل : <?php echo e($card->total_price); ?></span>
                                <span class="font-Y color-b-700 f-11">تعداد : <?php echo e($card->number); ?></span>
                                <span class="font-Y color-b-700 f-11">نام : <?php echo e($card->product->product->name); ?></span>
                                <span class="position-absolute model-color rounded-circle"
                                      style="background-image: url('/image/color/<?php echo e($card->color->code); ?>')"></span>
                                <span class="font-Y f-11 pointer" style="color: red"><i
                                        @click="delete_product_to_card(<?php echo e($card->id); ?>)"
                                        class="bi bi-trash"></i></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="w-100 d-flex flex-column justify-content-center align-items-center" style="height: 100%">
                            <img style="width: 100px" src="/image/icon/card.png" alt="سبد خرید خالی است">
                            <p dir="rtl"  class="mt-2 color-b-400 font-S">سبد خرید خالی است !</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-12 p-2 p-md-4 h-50">
            <div class="bg-light h-100 rounded-3 p-2 overflow-hidden">
                <p class="f-13 color-b-700 font-S text-end">فاکتورهای موفق</p>
                <div class="line"></div>
                <div class="box-item-panel h-75 overflow-scroll">
                    <?php if($factors->count() != 0): ?>
                        <?php $__currentLoopData = $factors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div
                                id="card_user_<?php echo e($factor->id); ?>"
                                class="w-100 my-2 p-2 position-relative rounded-3 d-flex justify-content-center align-items-center item-card-view"
                                style="height: 100px">
                                <a href="<?php echo e(route('user.tracking')); ?>" class="font-Y color-b-700 f-9 p-1 text-code-t-factor rounded-pill"> <?php echo e($factor->transaction_code); ?></a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="w-100 d-flex flex-column justify-content-center align-items-center" style="height: 100%">
                            <img style="width: 100px" src="/image/icon/buy.png" alt="سبد خرید خالی است">
                            <p  dir="rtl" class="mt-2 color-b-400 font-S">فاکتور پیدا نشد !</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/user/page/index_page.blade.php ENDPATH**/ ?>