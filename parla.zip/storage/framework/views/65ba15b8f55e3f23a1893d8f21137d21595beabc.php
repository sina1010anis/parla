<?php if($errors->any()): ?>
    <div class="view-err position-fixed p-3">
        <ul dir="rtl">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="f-13 color-b-100 my-3 text-end">
                    <?php echo e($error); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success text-center f-13">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('warning')): ?>
    <div class="alert alert-danger text-center f-13">
         <?php echo e(session('warning')); ?>

    </div>
<?php endif; ?>

<span class="msg-sm py-1 px-4 f-12 rounded-pill shadow" style="z-index:40"></span>
<?php /**PATH C:\wamp64\www\project\mar-tec\resources\views/errors/formAuth.blade.php ENDPATH**/ ?>