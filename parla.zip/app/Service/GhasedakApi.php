<?php

namespace App\Service;

class GhasedakApi
{
    public function send()
    {

    }
}
