<?php

namespace App\Repository\Create;

trait User
{
    public function createUser()
    {

    }
}
